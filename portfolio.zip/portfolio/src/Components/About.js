import React from 'react';
import './../Style/About.css';
import image1 from './../image/image1.jpeg';

export default function About() {
  return (
    <div className="about" id="about">
      <h1 className="heading-about">About Me</h1>
      <div className="content-about">
        <div className="image-content-about">
          <img src={image1} alt="Profile" />
        </div>
        <div className="info-content-about">
          <p>
            Hello! I'm Sthiti, a passionate web developer with a keen interest in building fast, scalable, and user-friendly
            applications. I love learning new technologies and continuously enhancing my skills.
          </p>
          <ul className="knowledge-about">
            <li>HTML</li>
            <li>CSS</li>
            <li>JavaScript</li>
            <li>React</li>
            <li>MongoDB</li>
            <li>Express.js</li>
            <li>Node.js</li>
          </ul>
          <button
            className="btn-about"
            onClick={() => {
              const contactSection = document.getElementById('contact');
              if (contactSection) {
                contactSection.scrollIntoView({ behavior: 'smooth' });
              }
            }}
          >
            Get in Touch
          </button>
        </div>
      </div>
    </div>
  );
}


