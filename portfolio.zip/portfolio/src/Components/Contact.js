// src/components/Contact.js
import React, { useState } from 'react';
import './../Style/Contact.css';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });

  const [status, setStatus] = useState('');
  const [isMessageSent, setIsMessageSent] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Prepare the request body
    const requestBody = {
      name: formData.name,
      email: formData.email,
      message: formData.message,
    };

    try {
      const response = await fetch('http://localhost:5000/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      if (response.ok) {
        setStatus('Message sent successfully!');
        setIsMessageSent(true);  // Set this to true when message is successfully sent
        setFormData({
          name: '',
          email: '',
          message: '',
        });
      } else {
        setStatus('Error sending message. Please try again later.');
      }
    } catch (error) {
      setStatus('Error sending message. Please try again later.');
    }
  };

  return (
    <div className="contact" id="contact">
      <h1>Contact Me</h1>
      <p className="contact-description">
        Have a question or want to work together? Feel free to drop me a message!
      </p>
      <div className="form-contact">
        {!isMessageSent ? (
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="name"
              placeholder="Your Name"
              value={formData.name}
              onChange={handleChange}
              required
            />
            <input
              type="email"
              name="email"
              placeholder="Your Email"
              value={formData.email}
              onChange={handleChange}
              required
            />
            <textarea
              name="message"
              placeholder="Your Message"
              rows="5"
              value={formData.message}
              onChange={handleChange}
              required
            />
            <button type="submit">Send Message</button>
          </form>
        ) : (
          <div className="success-message">
            <p>Message sent successfully! Thank you for contacting me.</p>
          </div>
        )}
      </div>
      <div className="info-contact">
        <div className="contact-item">
          <i className="fas fa-envelope"></i>
          {/* <p>Email: yourname@example.com</p> */}
        </div>
        <div className="contact-item">
          <i className="fas fa-phone-alt"></i>
          {/* <p>Phone: +123 456 7890</p> */}
        </div>
        <div className="contact-item">
          <i className="fas fa-map-marker-alt"></i>
          {/* <p>Location: Your City, Your Country</p> */}
        </div>
      </div>
      {status && <p>{status}</p>}
    </div>
  );
}
