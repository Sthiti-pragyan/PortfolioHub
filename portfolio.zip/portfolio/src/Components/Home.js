import React from 'react';
import image1 from './../image/image1.jpeg';
import './../Style/Home.css';

export default function Home() {
  return (
    <div className="home" id="home">
      <div className="sub-home">
        <div className="image-home">
          <img src={image1} alt="Profile" className="profile-image" />
        </div>
        <div className="text-home">
          <h1>
            Hi, I'm <span className="highlight-text">Sthiti</span>
          </h1>
          <h4>
            Welcome to my digital playground, where{' '}
            <span className="highlight-text">imagination</span> meets{' '}
            <span className="highlight-text">reality</span>.
          </h4>

          <p className="intro-text">
            As a passionate developer, designer, and creator, I'm dedicated to building innovative solutions that
            bridge the gap between technology and creativity. Join me as I continue to explore new challenges and
            create impactful digital experiences.
          </p>

          <p className="quote-text">
            "The future belongs to those who believe in the beauty of their dreams." – Eleanor Roosevelt
          </p>

          <button
            className="btn-home"
            onClick={() => {
              const aboutSection = document.getElementById('about');
              if (aboutSection) {
                aboutSection.scrollIntoView({ behavior: 'smooth' });
              }
            }}
          >
            Learn More About Me
          </button>
        </div>
      </div>
    </div>
  );
}
