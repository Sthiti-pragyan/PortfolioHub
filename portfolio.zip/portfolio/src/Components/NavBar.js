import React from 'react';
import './../Style/NavBar.css';

export default function NavBar() {
  return (
    <div>
      <nav>
        <div className="logo">MySite</div>
        <a href="#home" className="nav-link">Home</a>
        <a href="#about" className="nav-link">About</a>
        <a href="#projects" className="nav-link">Projects</a>
        <a href="#contact" className="nav-link">Contact</a>
      </nav>
    </div>
  );
}



