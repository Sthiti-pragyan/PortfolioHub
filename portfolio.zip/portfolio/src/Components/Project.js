import React from 'react';
import './../Style/Project.css'; // Custom styles

export default function Project() {
  const projects = [
    {
      title: 'LMS',
      description: 'A Library Management System to organize and manage book inventories efficiently.',
      //image: 'https://via.placeholder.com/150', // Replace with your LMS project image URL
      link: '', // No link provided
    },
    {
      title: 'CRM',
      description: 'A Customer Relationship Management app to streamline customer interactions.',
      //image: 'https://via.placeholder.com/150', // Replace with your CRM project image URL
      //link: 'https://example.com/crm', // Example link
    },
    {
      title: 'Blood-Link',
      description: 'Connecting donors and receivers for efficient blood donation.',
      //image: 'https://via.placeholder.com/150', // Replace with your Blood-Link project image URL
      //link: 'https://github.com/UjjwalSk/BloodLink', // Replace with actual link
    },
  ];

  return (
    <div id="projects" className="projects-section">
      <h1>My Projects</h1>
      <div className="projects-list">
        {projects.map((project, index) => (
          <div className="project-card" key={index}>
            
            <h2>{project.title}</h2>
            <p>{project.description || 'Description not available.'}</p>
            {project.link ? (
              <a href={project.link} target="_blank" rel="noopener noreferrer">
                View Project
              </a>
            ) : (
              <span className="no-link">Link not available</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}



