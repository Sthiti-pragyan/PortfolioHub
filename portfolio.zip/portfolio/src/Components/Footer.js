import React from 'react';
import './../Style/Footer.css'; // Custom styles for footer

export default function Footer() {
  return (
    <div className="footer">
      <div className="footer-content">
        {/* Footer Logo & Copyright */}
        <div className="footer-logo">
          <h3>@Sthiti</h3>
          <p>&copy; {new Date().getFullYear()} All rights reserved.</p>
        </div>

        {/* Quick Links Section */}
        <div className="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#projects">Projects</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </div>

        {/* Contact Info Section */}
        <div className="footer-contact">
          <h4>Contact Info</h4>
          <p>Email: sthitipragyan2002@gmail.com</p>
          <p>Phone: +91 123 456 7890</p>
        </div>

        {/* Social Media Links */}
        <div className="footer-social">
          <h4>Follow Us</h4>
          <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
            <i className="fab fa-linkedin"></i> LinkedIn
          </a>
        </div>
      </div>

      <div className="footer-bottom">
        <p>Designed with by @Sthiti</p>
      </div>
    </div>
  );
}


