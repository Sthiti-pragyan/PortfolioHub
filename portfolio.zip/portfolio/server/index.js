const express = require('express');
const cors = require('cors');
const connectDB = require('./db');
const app = express();
const PORT = process.env.PORT || 5000;

// Connect to MongoDB
connectDB();

// Middleware
app.use(cors());
app.use(express.json());

// Test Route
app.get('/', (req, res) => res.send('Server is running'));

// API Route
app.use('/api/contact', require('./routes/contactRoutes'));

app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
